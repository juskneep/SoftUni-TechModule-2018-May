function solve([input]) {
    input = input.split(' ').sort(function(a,b) {return a-b}).map(Number);
    let firstNum = input[0];
    let secondNum = input[1];
    let thirdNum = input[2];

    if (firstNum + secondNum == thirdNum){
        console.log(`${firstNum} + ${secondNum} = ${thirdNum}`);
    }
    else if (firstNum + thirdNum == secondNum){
        console.log(`${firstNum} + ${thirdNum} = ${secondNum}`);
    }
    else if(secondNum + thirdNum == firstNum){
        console.log(`${secondNum} + ${thirdNum} = ${firstNum}`);
    }
    else {
        console.log('No');
    }
}
solve(['1 1 2']);