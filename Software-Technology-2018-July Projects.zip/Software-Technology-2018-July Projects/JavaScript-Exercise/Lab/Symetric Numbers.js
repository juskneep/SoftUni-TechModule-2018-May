function solve(num) {
    for (let i = 1; i <= num; i++) {
        let reversed = i.toString().split('').reverse().join('');
        if (i == reversed){
            console.log(i);
        }
    }
}
solve(-750);