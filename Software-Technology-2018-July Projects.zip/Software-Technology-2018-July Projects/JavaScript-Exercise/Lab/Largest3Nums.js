function solve(arr) {
    let numbers = arr.sort(function (a,b) {
        return a-b;
    });
    let count = 0;
    for (let i = numbers.length - 1; i >= 0; i--) {
        count++;
        console.log(numbers[i]);
        if(count == 3)
            return;
    }
}
solve(['We start by HTML, CSS, JavaScript, JSON and REST. Later we touch some PHP, MySQL and SQL. Later we play with C#, EF, SQL Server and ASP.NET MVC. Finally, we touch some Java, Hibernate and Spring.MVC.']);