function solve() {
    let a = document.getElementById('firstNum').value;
    let b = document.getElementById('secondNum').value;

    let result = Number(a) + Number(b);

    document.getElementById('result').innerHTML = result;
}