function solve(input) {
    for (let i = 1; i <= input; i++)
        console.log(i);
}
