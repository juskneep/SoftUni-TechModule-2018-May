function solve(input) {
    let clas = {};
    for (let i = 0; i < input.length; i++) {
        let token = input[i].split(' -> ');
        if(token[1] == Number(token[1])){
            token[1] = Number(token[1]);
        }
        clas[token[0]] = token[1];
    }
    console.log(JSON.stringify(clas));
}
solve(['name -> Angel', 'surname -> Georgiev', 'age -> 20', 'grade -> 6.00', 'date -> 23/05/1995', 'town -> Sofia']);