function solve(input) {
    let arr = [];
    for (let i = 0; i < input.length; i++) {
        arr.unshift(input[i]);
    }
    console.log(arr.join('\n'));
}
solve();