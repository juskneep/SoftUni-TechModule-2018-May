function solve(input) {
    let arr = new Array(Number(input[0]));
    for (let i = 0; i < arr.length; i++) {
        arr[i] = 0;
    }
    for (let i = 1; i < input.length; i++) {
        let inp = input[i].split(' - ');
        arr[inp[0]] = inp[1];
    }
    console.log(arr.join('\n'));
}
solve(['5', '0 - 5', '0 - 7', '1 - 6', '5 - 6']);