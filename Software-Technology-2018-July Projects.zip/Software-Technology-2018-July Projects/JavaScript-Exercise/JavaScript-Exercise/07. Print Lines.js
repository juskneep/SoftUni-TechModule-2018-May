function solve(input) {
    for (let i = 0; input[i] != "Stop"; i++) {
        console.log(input[i]);
    }
}
