function solve() {
    let arr {};
}