function solve(input) {
    let firstNum = input[0];
    let secondNum = input[1];
    let thirdNum = input[2];
    let count = 0;
    if (firstNum < 0)
        count++;
    if (secondNum < 0)
        count++;
    if (thirdNum < 0)
        count++;
    if(count == 3 || count == 1)
        console.log("Negative");
    else
        console.log("Positive");
}
solve();