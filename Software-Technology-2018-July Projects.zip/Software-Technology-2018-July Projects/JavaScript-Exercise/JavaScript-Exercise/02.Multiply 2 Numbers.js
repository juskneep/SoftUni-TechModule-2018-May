function solve(num) {
    let firstNum = num[0];
    let secondNum = num[1];
    return firstNum * secondNum;
}