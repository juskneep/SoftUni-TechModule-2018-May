function solve(num) {
    let firstNum = num[0];
    let secondNum = num[1];
    if(firstNum <= secondNum)
        return firstNum * secondNum;
    else
        return firstNum / secondNum;
}