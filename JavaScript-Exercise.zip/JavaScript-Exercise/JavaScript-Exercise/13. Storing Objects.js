function solve(input) {
    let classes = {};
    for (let i = 0; i < input.length; i++) {
        let arr = input[i].split(' -> ');
        classes[arr[0]] = [];
        classes[arr[0]].push(arr[1]);
        classes[arr[0]].push(arr[2]);
    }
    for (let i = 0; i < input.length; i++) {
        let arr = input[i].split(' -> ');
        console.log(`Name: ${arr[0]}`);
        console.log(`Age: ${classes[arr[0]][0]}`);
        console.log(`Grade: ${classes[arr[0]][1]}`);

    }
}
solve(["Pesho -> 13 -> 6.00", "Ivan40 -> 16 -> 6.56", "Pesho -> 14 -> 5.98"]);
