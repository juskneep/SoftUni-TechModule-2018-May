function solve(input) {
    for (let i = Number(input); i >= 1; i--) {
        console.log(i);
    }
}