function solve(input) {
    let arr = [];
    for (let i = 0; i < input.length; i++) {
        let inp = input[i].split(' ');
        if(inp[0] == "remove")
            arr.splice(inp[1], 1);
        else
            arr.push(inp[1]);
    }
    console.log(arr.join('\n'));
}