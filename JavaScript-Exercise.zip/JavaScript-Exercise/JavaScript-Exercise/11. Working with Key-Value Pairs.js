function solve(input) {
    let finalClass = {};
    for (let i = 0; i < input.length - 1; i++) {
        let values = input[i].split(' ');
        finalClass[values[0]] = values[1];
    }
    if(input[input.length - 1] in finalClass) {
        console.log(finalClass[input[input.length - 1]]);
    }
    else {
        console.log("None");
    }
}