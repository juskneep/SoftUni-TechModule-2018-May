function solve(input) {
    let dictList = {};
    let finalKey = '';
    for (let i = 0; i < input.length; i++) {
        let arr = input[i].split(' ');
        let key = arr[0];
        let value = arr[1];
        if(value === undefined){
            finalKey = key;
            break;
        }
        if(key in dictList){
            dictList[key].push(value);
        }
        else
        {
            dictList[key] = [];
            dictList[key].push(value);
        }
    }
    if(finalKey in dictList) {
        console.log(dictList[finalKey].join('\n'));
    }
    else{
        console.log("None");
    }
}
solve(["key value", "key eulav", "da we", "key"]);