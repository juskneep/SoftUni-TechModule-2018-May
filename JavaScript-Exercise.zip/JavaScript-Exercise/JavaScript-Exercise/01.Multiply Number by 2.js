function solve(num) {
    return num * 2;
}