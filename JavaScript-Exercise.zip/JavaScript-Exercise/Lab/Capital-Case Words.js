function solve(input){
    let words = input.join(' ').match(/[\w\d]+/gm);
    let upperWords = [];
    for (let i = 0; i < words.length; i++) {
        if(words[i].toUpperCase() == words[i]) {
                upperWords.push(words[i].toString());
        }
    }
    console.log(upperWords.filter(word => word != '').join(', '));
}
solve(['We start by HTML, CSS, JavaScript, JSON and REST.\n' +
'Later we touch some PHP, MySQL and SQL.\n' +
'Later we play with C#, EF, SQL Server and ASP.NET MVC.\n' +
'Finally, we touch some Java, Hibernate and Spring.MVC.']);