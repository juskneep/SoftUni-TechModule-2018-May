function solve(arr) {
    let towns = arr.map(JSON.parse);
    let sum = {};
    for (let town of towns) {
        if (town.town in sum) {
            sum[town.town] += town.income;
        }
        else {
            sum[town.town] = town.income;
        }
    }
    let town = Object.keys(sum).sort();
    for (let t of town) {
        console.log(`${t} -> ${sum[t]}`);
    }
}
solve(["{\"town\":\"Sofia\", \"income\":200}", "{\"town\":\"Pleven\", \"income\":300}"]);