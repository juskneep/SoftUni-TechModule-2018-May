const path = require('path');

module.exports = {
    development: {
        rootFolder: path.normalize(path.join(dirname, '/../')),
},
    production:{}
};



